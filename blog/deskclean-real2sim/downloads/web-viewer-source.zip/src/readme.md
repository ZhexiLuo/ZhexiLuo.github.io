# Export

export_web_scene.py converts the frozen Blender replay to one animated GLB. See the root README for the Blender command.
